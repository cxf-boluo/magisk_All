# magisk_All
## magisk 一键集成环境，再也不用每次刷完机繁琐得配置环境了！
### 集成工具：MT管理器、Igniter、启用webView调试、HTTPCanary、proxydroid、SSLping
### 集成模块：lsposed、Shamiko
### 开机自启动：frida-server  android-server
### 默认抓包证书从用户证书存储移动到系统目录下



