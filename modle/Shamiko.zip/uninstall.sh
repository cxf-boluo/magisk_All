rm -rf /data/adb/shamiko
